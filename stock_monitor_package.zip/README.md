# Stock Monitor - 24/7 Stock Alert System

A comprehensive Python-based stock monitoring system that tracks price movements across US exchanges in real-time. Monitors stocks for 20% gains within 2-hour trading windows and sends Discord notifications while filtering out news-driven price movements.

## Features

- **24/7 Continuous Monitoring**: Tracks stock prices every 10 minutes
- **Market-Hours-Aware Timing**: Only counts actual trading time (4 AM - 8 PM ET, weekdays)
- **Smart Gain Detection**: Identifies 20%+ gains within 2-hour trading windows
- **News Filtering**: Filters out earnings/announcement-driven moves to focus on technical momentum
- **Discord Notifications**: Rich embed alerts with price details and timing
- **Daily Deduplication**: Prevents multiple alerts for the same stock per day
- **Production Ready**: Comprehensive error handling, logging, and retry mechanisms

## Quick Start

### 1. Install Dependencies
```bash
pip install yfinance schedule requests feedparser pytz
```

### 2. Set Discord Webhook
```bash
export DISCORD_WEBHOOK_URL="https://discord.com/api/webhooks/YOUR_WEBHOOK_URL"
```

### 3. Run the Monitor
```bash
python complete_stock_monitor.py
```

## Configuration

The system automatically creates a `config.json` file with default settings:

```json
{
    "symbols": ["AAPL", "GOOGL", "MSFT", "AMZN", "TSLA", "META", "NVDA", "AMD"],
    "gain_threshold": 20.0,
    "time_window_hours": 2,
    "check_interval_minutes": 10,
    "market_hours_aware": true,
    "max_retries": 3,
    "retry_delay": 30,
    "request_delay": 3
}
```

### Configuration Options

- **symbols**: List of stock symbols to monitor
- **gain_threshold**: Minimum percentage gain to trigger alerts (default: 20%)
- **time_window_hours**: Time window for gain calculations (default: 2 hours)
- **check_interval_minutes**: How often to check stocks (default: 10 minutes)
- **market_hours_aware**: Use trading-time-aware calculations (recommended: true)

## Discord Setup

1. Create a Discord webhook in your server:
   - Go to Server Settings → Integrations → Webhooks
   - Click "New Webhook"
   - Copy the webhook URL

2. Set the environment variable:
   ```bash
   export DISCORD_WEBHOOK_URL="your_webhook_url_here"
   ```

## How It Works

1. **Price Tracking**: Maintains rolling price history for each stock
2. **Market Hours Detection**: Identifies US trading hours including pre-market and after-hours
3. **Gain Calculation**: Finds lowest price within 2-hour trading window and calculates percentage gain
4. **News Filtering**: Checks Yahoo Finance and Google News for company-specific news
5. **Alert Generation**: Sends Discord notification if gain threshold is met and no recent news found
6. **Cycle Completion**: Sends summary notifications after each monitoring cycle

## Market Hours

The system recognizes:
- **Extended Hours**: 4:00 AM - 8:00 PM ET (Monday-Friday)
- **Regular Hours**: 9:30 AM - 4:00 PM ET (Monday-Friday)
- **Market Holidays**: US market holidays are excluded
- **Weekends**: No trading time counted

## Output Examples

### Stock Alert
- Stock symbol and percentage gain
- Current price vs starting price
- Actual duration of the move
- Timestamp in AEST timezone

### Cycle Completion
- Number of stocks processed
- Alerts sent in this cycle
- Any errors encountered
- Next check time

## Logging

- Console output with AEST timestamps
- File logging to `stock_monitor.log`
- Progress updates every 100 stocks
- Error tracking and reporting

## Error Handling

- Automatic retries for failed API calls
- Graceful handling of delisted stocks
- Rate limiting to avoid API restrictions
- Service auto-restart on critical errors

## Advanced Usage

### Adding More Stocks
Edit `config.json` and add symbols to the "symbols" array:
```json
"symbols": ["AAPL", "GOOGL", "MSFT", "YOUR_SYMBOL_HERE"]
```

### Adjusting Sensitivity
Change the gain threshold in `config.json`:
```json
"gain_threshold": 15.0  // Alert on 15% gains instead of 20%
```

### Custom Check Intervals
Modify check frequency in `config.json`:
```json
"check_interval_minutes": 5  // Check every 5 minutes instead of 10
```

## Requirements

- Python 3.7+
- Internet connection for API access
- Discord webhook URL
- Sufficient system resources for continuous operation

## License

Open source - feel free to modify and distribute.

## Support

This is a self-contained monitoring system designed for continuous operation. Monitor the logs for any issues and ensure your Discord webhook remains active.